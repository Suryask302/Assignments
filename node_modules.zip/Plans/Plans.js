let Plans = {
    MUSIC: {
        FREE: {
            amount: 0,
            time: 1
        },
        PERSONAL: {
            amount: 100,
            time: 1
        }
        , PREMIUM: {
            amount: 250,
            time: 3
        }
    }
    , VIDEO: {
        FREE: {
            amount: 0,
            time: 1
        },
        PERSONAL: {
            amount: 200,
            time: 0
        }
        , PREMIUM: {
            amount: 500,
            time: 3
        }
    },
    PODCAST: {
        FREE: {
            amount: 0,
            time: 1
        },
        PERSONAL: {
            amount: 100,
            time: 1
        }
        , PREMIUM: {
            amount: 300,
            time: 2
        }
    }
}

module.exports = {
    Plans
}