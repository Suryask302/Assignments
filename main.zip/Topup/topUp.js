let topUp = {
    FOUR_DEVICE: {
        amount: 50,
        device: 4
    },
    TEN_DEVICE: {
        amount: 100,
        device: 10
    },

}

module.exports = {
    topUp
}